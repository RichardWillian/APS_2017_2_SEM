package Constantes;

public class ConstantesMensagens {


	public static final String ADVERTENCIA_ECOLOGICA_1 = "PARA DE JOGAR LIXO !!!";
	public static final String ADVERTENCIA_ECOLOGICA_2 = "DO PONTO DE VISTA DO PLANETA, \n N�O EXISTE JOGAR LIXO FORA: \n PORQUE N�O EXISTE \"FORA\".";
	public static final String ADVERTENCIA_ECOLOGICA_3 = "Ambiente limpo n�o � o que mais se limpa e sim o que menos se suja.";
	public static final String ADVERTENCIA_ECOLOGICA_4 = "PARA DE JOGAR LIXO !!!";
	public static final String ADVERTENCIA_ECOLOGICA_5 = "PARA DE JOGAR LIXO !!!";
	public static final String ADVERTENCIA_ECOLOGICA_6 = "PARA DE JOGAR LIXO !!!";
	public static final String ADVERTENCIA_ECOLOGICA_7 = "PARA DE JOGAR LIXO !!!";
}
