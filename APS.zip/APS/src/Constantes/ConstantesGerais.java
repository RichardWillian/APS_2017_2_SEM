package Constantes;

public class ConstantesGerais {

	public static final int CIMA = 0;
	public static final int BAIXO = 1;
	public static final int DIREITA = 2;
	public static final int ESQUERDA = 3;
	public static final int TAMANHO_PASSO_ECOMAN = 10;
	public static final int DISTANCIA_DIRTYMAN = 40;
	public static final int DISTANCIA_LIXO = 20;
	public static final int DISTANCIA_CAPTURAR_LIXO = 40;
	public static final int DISTANCIA_PARAR_DIRTYMAN = 60;
}
