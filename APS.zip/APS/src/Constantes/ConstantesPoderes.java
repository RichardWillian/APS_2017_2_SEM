package Constantes;

public class ConstantesPoderes {


	

	public static final int CONGELAR = 0;
	public static final int DIMINUIR_VELOCIDADE = 1;
}
